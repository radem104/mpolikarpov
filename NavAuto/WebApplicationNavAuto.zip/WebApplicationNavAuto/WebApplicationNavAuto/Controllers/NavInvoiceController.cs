﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using WebApplicationNavAuto.Common;
using WebApplicationNavAuto.Models;
using WebApplicationNavAuto.Models.ModelsToSave;

namespace WebApplicationNavAuto.Controllers
{
    public class NavInvoiceController : CreatioController
    {
        /// <summary>
        /// Auto create invoice
        /// </summary>
        /// <param name="agreementName">Number of agreement</param>
        /// <param name="invoiceAmount">Amount of invoice</param>
        /// <returns></returns>
        [HttpPost("/Create")]
        public IActionResult Create(string agreementName, decimal invoiceAmount)
        {
            try
            {
                var invoiceUrl = $"{appUrl}/0/odata/NavInvoice";

                var agreement = GetAgreementByName(agreementName);
                if (string.IsNullOrEmpty(agreement.ErrorText))
                {
                    var invoice = new InvoiceToSave
                    {
                        NavName = $"Auto agreement({agreementName}) invoice {DateTime.Now.Date}",
                        NavDate = DateTime.Now.Date,
                        NavAgreementId = agreement.Value.Select(x => x.Id).FirstOrDefault() ?? new Guid(),
                        NavPayDate = DateTime.Now,
                        NavAmount = invoiceAmount,
                        NavInvoiceTypeId = new Guid("1C038CB2-3B91-4F07-855E-67722210809B")
                    };

                    var requestParams = new CreatioRequest
                    {
                        Url = invoiceUrl,
                        Method= "POST"
                       
                    };

                    var request = CreateRequest(requestParams, JsonConvert.SerializeObject(invoice));
                    var response = GetResponseData<object>(request);

                }
                else
                {
                    return BadRequest(agreement.ErrorText);
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
            return Ok("New invoice added");

        }
        /// <summary>
        /// Find greemnet by number
        /// </summary>
        /// <param name="agreementName">Digits and '-'</param>
        /// <returns></returns>

        private CreatioResponse<NavAgreement> GetAgreementByName(string agreementName)
        {
            var response = new CreatioResponse<NavAgreement>();
            try
            {
                var agreementUrl = $"{appUrl}/0/odata/NavAgreement?$filter=NavName eq '{agreementName}'";
                var requestParams = new CreatioRequest
                {
                    Url = agreementUrl
                };
                var request = CreateRequest(requestParams);
               
                response = GetResponseData<NavAgreement>(request);

                if(response.Value.Count !=0)
                {
                    if(response.Value.Count > 1)
                    {
                        response.ErrorText = "Exception. More than 1 agreements in that name";
                    }
                }
                else
                {
                    response.ErrorText = "Agreement not found";
                }
            }
            catch (Exception exc)
            {
                response.ErrorText = exc.Message;
            }
            return response;
        }
    }
}
