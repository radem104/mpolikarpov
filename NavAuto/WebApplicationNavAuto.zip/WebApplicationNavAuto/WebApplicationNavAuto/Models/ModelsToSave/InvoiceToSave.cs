﻿using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;

namespace WebApplicationNavAuto.Models.ModelsToSave
{
    /// <summary>
    /// Model to create new invoice in system(only required fileds)
    /// </summary>
    public class InvoiceToSave
    {
        [Required]
        public string NavName { get; set; }
        [Required]
        public DateTime NavDate { get; set; }
        [Required]
        public Guid NavAgreementId { get; set; }
        [Required]
        public DateTime NavPayDate { get; set; }
        [Required]
        public Guid NavInvoiceTypeId { get; set; }
        [Required]
        public decimal NavAmount { get; set; }

      /*  public string GetJsonToSave()

        {
            var insertQuery = new InsertQuery()
            {
                RootSchemaName = "NavInvoice",
                ColumnValues = new ColumnValues()
            };
            var columnExpressionName = new ColumnExpression
            {
                ExpressionType = EntitySchemaQueryExpressionType.Parameter,
                Parameter = new Parameter
                {
                    Value = NavName,
                    DataValueType = DataValueType.Text
                }
            };
            var columnExpressionDate = new ColumnExpression
            {
                ExpressionType = EntitySchemaQueryExpressionType.Parameter,
                Parameter = new Parameter
                {
                    Value = DateTime.Now.Date,
                    DataValueType = DataValueType.Date
                }
            };
            var columnExpressionAgreementId = new ColumnExpression
            {
                ExpressionType = EntitySchemaQueryExpressionType.Parameter,
                Parameter = new Parameter
                {
                    Value = NavAgreementId,
                    DataValueType = DataValueType.Guid
                }
            };
            var columnExpressionPayDate = new ColumnExpression
            {
                ExpressionType = EntitySchemaQueryExpressionType.Parameter,
                Parameter = new Parameter
                {
                    Value = NavPayDate,
                    DataValueType = DataValueType.DateTime
                }
            };
            var columnExpressionInvTypeId = new ColumnExpression
            {
                ExpressionType = EntitySchemaQueryExpressionType.Parameter,
                Parameter = new Parameter
                {
                    Value = NavInvoiceTypeId,
                    DataValueType = DataValueType.Guid
                }
            };
            var columnExpressionAmount = new ColumnExpression
            {
                ExpressionType = EntitySchemaQueryExpressionType.Parameter,
                Parameter = new Parameter
                {
                    Value = NavAmount,
                    DataValueType = DataValueType.Money
                }
            };
            insertQuery.ColumnValues.Items = new Dictionary<string, ColumnExpression>();

            insertQuery.ColumnValues.Items.Add("NavName", columnExpressionName);
            insertQuery.ColumnValues.Items.Add("NavDate", columnExpressionDate);
            insertQuery.ColumnValues.Items.Add("NavAgreementId", columnExpressionAgreementId);
            insertQuery.ColumnValues.Items.Add("NavPayDate", columnExpressionPayDate);
            insertQuery.ColumnValues.Items.Add("NavInvoiceTypeId", columnExpressionInvTypeId);
            insertQuery.ColumnValues.Items.Add("NavAmount", columnExpressionAmount);

            var json =  JsonConvert.SerializeObject(insertQuery);
            return json;
        }*/
    }
}
