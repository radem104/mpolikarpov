﻿namespace WebApplicationNavAuto.Models
{
    public class CreatioResponse<T>
    {
        public string? Context { get; set; }
        public List<T> Value { get; set; } = new List<T>();
        public string? ErrorText { get; set; }
    }
}
