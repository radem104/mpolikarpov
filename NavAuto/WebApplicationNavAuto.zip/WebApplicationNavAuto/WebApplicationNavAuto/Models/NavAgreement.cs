﻿namespace WebApplicationNavAuto.Models
{
    public class NavAgreement
    {
        public Guid? Id { get; set; }
        public DateTime? CreatedOn { get; set; }
        public Guid? CreatedById { get; set; }
        public DateTime? ModifiedOn { get; set; }
        public Guid? ModifiedById { get; set; }
        public int ProcessListeners { get; set; }
        public string? NavName { get; set; }
        public string? NavNotes { get; set; }
        public Guid? NavAutoId { get; set; }
        public string? NavContactId { get; set; }
        public DateTime NavDate { get; set; }
        public decimal NavSumma { get; set; }
        public bool NavFact { get; set; }
        public Guid? NavCreditId { get; set; }
        public int NavCreditPeriod { get; set; }
        public decimal NavCreditAmount { get; set; }
        public decimal NavFullCreditAmount { get; set; }
        public decimal NavInitialFee { get; set; }
        public decimal NavFactSumma { get; set; }
        public DateTime? NavPaymentPlanDate { get; set; }
    }
}
