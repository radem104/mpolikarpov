﻿using Microsoft.AspNetCore.Mvc;
using System.Net.Http.Headers;
using System.Net;
using System.Text;
using WebApplicationNavAuto.Models;
using Newtonsoft.Json;
using System.Text.Json.Nodes;

namespace WebApplicationNavAuto.Common
{
    /// <summary>
    /// Base class to creatio odata requests
    /// </summary>
    public class CreatioController : ControllerBase
    {
        protected CookieContainer authCookie;
        protected string appUrl;
        public CreatioController()
        {
            var config = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();

            appUrl = config.GetValue<string>("CreatioApp:AppUrl");
            var userName = config.GetValue<string>("CreatioApp:UserName");
            var password = config.GetValue<string>("CreatioApp:password");

            var autorization = new CreatioLogin(appUrl,userName, password);
            autorization.TryLogin();
            authCookie = autorization.AuthCookie;
        }

        protected HttpWebRequest CreateRequest(CreatioRequest requestParams, string data = null)
        {
            var request = (HttpWebRequest)WebRequest.Create(requestParams.Url);
            request.ContentType = requestParams.ContentType;
            request.Method = requestParams.Method;
            request.KeepAlive = requestParams.KeepAlive;
            request.CookieContainer = authCookie;
            if (request.Method == "POST")
            {
                byte[] jsonArray = Encoding.UTF8.GetBytes(data);
                request.ContentLength = jsonArray.Length;
                WriteStream(request, jsonArray);
                AddCsrfToken(request);

            }
            if (!string.IsNullOrEmpty(requestParams.Data))
            {
                using var requestStream = request.GetRequestStream();
                using var writer = new StreamWriter(requestStream);
                writer.Write(requestParams.Data);
            }
            return request;
        }


        protected CreatioResponse<T> GetResponseData<T>(HttpWebRequest request)
        {
            var responseData = new CreatioResponse<T>();

            using (var response = (HttpWebResponse)request.GetResponse())
            {
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    using (var reader = new StreamReader(response.GetResponseStream()))
                    {
                        var result = reader.ReadToEnd();
                        responseData = JsonConvert.DeserializeObject<CreatioResponse<T>>(result);
                    }
                }
                return responseData ?? new CreatioResponse<T>();
            }
        }

        private void WriteStream(HttpWebRequest request, byte[] jsonArray)
        {
            using (var requestStream = request.GetRequestStream())
            {
                requestStream.Write(jsonArray, 0, jsonArray.Length);
            }
        }

        protected void AddCsrfToken(HttpWebRequest request)
        {
            var cookie = authCookie.GetCookies(new Uri(appUrl))["BPMCSRF"];
            if (cookie != null)
            {
                request.Headers.Add("BPMCSRF", cookie.Value);
            }
        }

    }
}
